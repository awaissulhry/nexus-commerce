import { contentListing } from './content-read.js'
import { resolveContent, type ContentProduct, type ResolvedContent } from './content-resolver.js'
import { languageTag, marketLanguages } from './market-languages.js'

export interface AmazonContentInput {
  product: ContentProduct
  parent?: ContentProduct | null
  listing?: Record<string, any> | null
  marketplace: string
  marketplaceId: string
  fields?: readonly string[]
}

/** Publish and preflight consume the exact same resolved values and review verdict. */
export async function resolvePublishContent(input: Omit<AmazonContentInput, 'marketplaceId'> & { channel?: string }) {
  const channel = input.channel ?? 'AMAZON'
  const languages = await marketLanguages(channel, input.marketplace)
  const coordinate = { channel, market: input.marketplace,
    ...(input.listing?.channelConnectionId ? { accountId: input.listing.channelConnectionId } : {}),
    ...(input.listing?.aliasKey ? { aliasId: input.listing.aliasKey } : {}) }
  const listing = contentListing(input.product, input.listing, coordinate, languages)
  return languages.map(language => ({ language, fields: Object.fromEntries((input.fields ?? ['title', 'description', 'bulletPoints', 'keywords']).map(field => {
    const args = { product: input.product, parent: input.parent, listing, field, address: { requested: language, coordinate } }
    const resolved = resolveContent(args)
    // A following legacy snapshot must not conceal an unreviewed shared draft
    // from publish preflight. Approved writes already update these snapshots.
    if (resolved.drift && resolved.follows) {
      const shared = resolveContent({ ...args, listing: null })
      if (shared.translation && shared.translation.source !== 'manual' && !shared.translation.reviewedAt) return [field, shared]
    }
    return [field, resolved]
  })) as Record<string, ResolvedContent> }))
}

export function publishReviewIssues(content: Awaited<ReturnType<typeof resolvePublishContent>>) {
  return content.flatMap(row => Object.entries(row.fields).filter(([, value]) =>
    value.translation && value.translation.source !== 'manual' && !value.translation.reviewedAt,
  ).map(([field]) => ({ language: row.language, field, severity: 'ERROR' as const,
    message: `Review the ${new Intl.DisplayNames(['en'], { type: 'language' }).of(row.language)} (${row.language}) ${field} before publishing.` })))
}

/** Pure payload construction after database reads; never invokes a publisher or provider. */
export async function buildAmazonContentAttributes(input: AmazonContentInput): Promise<Record<string, any[]>> {
  const content = await resolvePublishContent(input)
  const issues = publishReviewIssues(content)
  if (issues.length) throw Object.assign(new Error(issues.map(issue => issue.message).join(' ')), { statusCode: 422, issues })
  const attributes: Record<string, any[]> = {}
  const keys: Record<string, string> = { title: 'item_name', description: 'product_description', bulletPoints: 'bullet_point', keywords: 'generic_keyword' }
  for (const row of content) for (const [field, resolved] of Object.entries(row.fields)) {
    const key = keys[field]
    if (!key || resolved.value == null || resolved.value === '') continue
    const values = Array.isArray(resolved.value) ? resolved.value : [resolved.value]
    for (const value of values.filter(value => value !== '' && value != null)) {
      const entry = { value: String(value), marketplace_id: input.marketplaceId, language_tag: languageTag(resolved.language, input.marketplace) }
      const entries = attributes[key] ??= []
      entries.push(entry)
    }
  }
  return attributes
}
