import { beforeEach, expect, it, vi } from 'vitest'
const mocks = vi.hoisted(() => ({ row: vi.fn(), provider: vi.fn() }))
vi.mock('../../../db.js', () => ({ default: { $queryRawUnsafe: async () => [{ stamp: 'cached', n: 1 }], categorySchema: { findFirst: mocks.row } } }))
vi.mock('../../../lib/workspace-cache.js', () => ({ WorkspaceCache: Map }))
vi.mock('../../categories/seller-schema.service.js', () => ({ amazonSellerSpec: mocks.provider }))
vi.mock('./amazon.js', () => ({ amazonSpecFromDefinition: (input: unknown) => input }))
import { clearChannelSpecCache, loadAmazonSpec } from './index.js'
beforeEach(() => { clearChannelSpecCache(); vi.clearAllMocks() })
it('uses the stored schema with its database date even when an account is selected', async () => {
  const fetchedAt = new Date('2026-08-01T00:00:00Z')
  mocks.row.mockResolvedValue({ schemaDefinition: { properties: {} }, fetchedAt, schemaVersion: 'stored' })
  for (let i = 0; i < 3; i++) expect(await loadAmazonSpec('DE', 'OUTERWEAR', 'account')).toMatchObject({ fetchedAt, schemaVersion: 'stored' })
  expect(mocks.provider).not.toHaveBeenCalled()
  expect(mocks.row).toHaveBeenCalledTimes(1)
})
it('retains the seller-specific fallback only when the database has no schema', async () => {
  mocks.row.mockResolvedValue(null); mocks.provider.mockResolvedValue({ absent: false })
  expect(await loadAmazonSpec('DE', 'OUTERWEAR', 'account')).toEqual({ absent: false })
  expect(mocks.provider).toHaveBeenCalledWith('account', 'DE', 'OUTERWEAR')
})
