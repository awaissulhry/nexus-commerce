import { afterEach, beforeEach, expect, it, vi } from 'vitest'
const fixtures = vi.hoisted(() => ({ market: vi.fn(), provider: vi.fn(() => { throw new Error('Provider forbidden') }) }))
vi.mock('../../db.js', () => ({ default: { marketplace: { findFirst: fixtures.market } } }))
vi.mock('../../clients/amazon-sp-api.client.js', () => ({ amazonSpApiClient: { putListingsItem: fixtures.provider, patchListingsItem: fixtures.provider } }))
import { buildAmazonContentAttributes } from './amazon-content-payload.js'
import { buildMarketplaceAmazonAttributes } from '../../routes/marketplaces.routes.js'
import { buildAmazonListingPatch } from '../outbound-sync.service.js'
const product = { id: 'product', name: 'Source title', description: 'Source description', translations:
  ['de', 'nl', 'fr', 'en'].map(language => ({ language, name: `Title ${language}`, description: `Description ${language}`, bulletPoints: [`Bullet ${language}`], source: 'manual' as const })) }
beforeEach(() => {
  vi.clearAllMocks(); vi.stubGlobal('fetch', fixtures.provider)
  fixtures.market.mockImplementation(async ({ where }) => { expect(where.channel).toBe('AMAZON'); return { languages: where.code === 'BE' ? ['nl', 'fr'] : where.code === 'DE' ? ['de'] : ['en'] } })
})
afterEach(() => { expect(fixtures.provider).not.toHaveBeenCalled(); vi.unstubAllGlobals() })
it.each([['DE', 'de', 'de_DE'], ['BE', 'nl', 'nl_BE'], ['BE', 'fr', 'fr_BE'], ['UK', 'en', 'en_GB']])('builds resolved %s %s entries in both real builders', async (marketplace, language, tag) => {
  const content = { product }
  const attributes = await buildMarketplaceAmazonAttributes({ marketplace, marketplaceId: 'fixture', attributes: {}, content })
  expect(attributes.item_name).toContainEqual({ value: `Title ${language}`, marketplace_id: 'fixture', language_tag: tag })
  const patch = await buildAmazonListingPatch({ title: 'stale queue snapshot' }, marketplace, 'OUTERWEAR', null, content)
  expect(patch.patches.find((p: any) => p.path === '/attributes/item_name').value).toEqual(attributes.item_name.map((v: any) => ({ ...v, marketplace_id: expect.any(String) })))
  expect(attributes.item_name).toHaveLength(marketplace === 'BE' ? 2 : 1)
  expect(attributes.product_description.map((v: any) => v.value)).toContain(`Description ${language}`)
})
it('never relabels source fallback as a translated value', async () => {
  const attributes = await buildAmazonContentAttributes({ product: { id: 'source', name: 'Italian' }, marketplace: 'DE', marketplaceId: 'fixture' })
  expect(attributes.item_name[0].language_tag).toBe('it_DE')
})
it('names the unreviewed French language before a payload can reach a provider', async () => {
  const draft = { ...product, translations: product.translations.map(row => row.language === 'fr' ? { ...row, source: 'ai' as const, reviewedAt: null } : row) }
  await expect(buildAmazonContentAttributes({ product: draft, marketplace: 'BE', marketplaceId: 'fixture' })).rejects.toThrow('French (fr) title')
})

it('a following legacy snapshot cannot conceal an unreviewed German draft', async () => {
  const draft = { ...product, translations: [{ language: 'de', name: 'German draft', source: 'ai' as const, reviewedAt: null }] }
  await expect(buildAmazonContentAttributes({ product: draft, listing: { id: 'listing', productId: product.id, channel: 'AMAZON', marketplace: 'DE', title: 'Old listing snapshot', followMasterTitle: true }, marketplace: 'DE', marketplaceId: 'fixture' })).rejects.toThrow('German (de) title')
})
