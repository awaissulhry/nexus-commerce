import { marketLanguages, type MarketLanguageRow } from './market-languages.js'
import { PRIMARY_CONTENT_LOCALE } from './content-locale.js'
import type { StudioSheet } from './studio-sheet.service.js'
export type ScopeState = 'ready' | 'warn' | 'blocked' | 'absent'

export interface ScopeReadiness {
  languages?: Array<{ language: string; pct: number | null; state: ScopeState }>
  /** `master`, or the channel name (`AMAZON`, `EBAY`, …). */
  id: string
  label: string
  pct: number | null
  required: { filled: number; total: number }
  state: ScopeState
  /** Why `pct` is null, or why the scope is absent. Rendered beside the chip. */
  note?: string
  aliasCount: number
  /** Rules applicable to the selected categories. Explicit listing values can
   * also supply fields without a mapping rule. `null` for Master. */
  mappingRules: number | null
}

export interface ProductReadiness {
  market: string
  locale: string
  scopes: ScopeReadiness[]
  computedAt: string
  matrix: ReadinessMatrixEntry[]
}

/** Summarize the same rows and validators the editor serves, including listing aliases. */
export function readinessFromSheet(sheet: StudioSheet, mappingRules: number | null): ScopeReadiness {
  const required = sheet.rows.reduce((sum, row) => ({
    filled: sum.filled + row.completeness.required.filled,
    total: sum.total + row.completeness.required.total,
  }), { filled: 0, total: 0 })
  const issues = sheet.rows.flatMap(row => row.readiness.issues)
  const missing = sheet.meta.schemaMissing
  const mappingUnavailable = sheet.scope.kind === 'channel' && (!sheet.meta.mapping || !!sheet.meta.mapping.skippedReason || sheet.meta.mapping.missingProductIds.length > 0)
  const unavailable = missing.length > 0 || required.total === 0 || mappingUnavailable
  return {
    id: sheet.scope.channel ?? 'master', label: sheet.scope.label, required,
    pct: unavailable ? null : Math.round(100 * required.filled / required.total),
    state: issues.some(i => i.severity === 'error') ? 'blocked' : missing.length > 0 || required.total === 0 ? 'absent'
      : mappingUnavailable || issues.length > 0 ? 'warn' : 'ready',
    ...(missing.length ? { note: `Category metadata is incomplete: ${missing.join(', ')}` }
      : mappingUnavailable ? { note: sheet.meta.mapping?.skippedReason ?? 'Channel mapping values have not been fully checked' }
      : required.total === 0 ? { note: 'No required attributes are defined for this scope' }
      : { note: `${required.filled} of ${required.total} required values filled across this scope. Row completeness also includes optional attributes. Information completeness does not establish publication eligibility or provider acceptance.` }),
    aliasCount: sheet.aliases.filter(alias => alias.id !== null).length,
    mappingRules,
  }
}


export interface MissingReadinessField { productId: string; field: string; label: string; reason: string }
export interface ReadinessCoordinate { channel: string | null; market: string | null; accountId: string | null; aliasId: string | null }
export interface ReadinessMatrixEntry extends ScopeReadiness, ReadinessCoordinate {
  language: string
  coordinateKey: string
  missing: MissingReadinessField[]
  computedAt: string | null
}

export function readinessCoordinateKey(c: ReadinessCoordinate): string {
  return JSON.stringify([c.channel, c.market, c.accountId, c.aliasId])
}

/** Ordered union of the marketplace authority, with the shared source first. */
export function readinessLanguages(markets: readonly MarketLanguageRow[]): string[] {
  return [...new Set([PRIMARY_CONTENT_LOCALE, ...markets.flatMap(m => marketLanguages(m.channel, m.code, [m]))])]
}
