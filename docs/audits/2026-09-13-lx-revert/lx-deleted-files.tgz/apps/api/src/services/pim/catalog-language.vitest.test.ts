import { beforeEach, describe, expect, it, vi } from 'vitest'
const db = vi.hoisted(() => ({ product: { findMany: vi.fn() }, readinessIndex: { findMany: vi.fn() }, $queryRaw: vi.fn() }))
vi.mock('../../db.js', () => ({ default: db }))
import { catalogLanguageValues, indexFallsBack, orderCatalogLanguage, restrictCatalogLanguage } from './catalog-language.js'
beforeEach(() => vi.resetAllMocks())
describe('catalog language read path', () => {
  it('matches the indexed fallback verdict, including an optional field', () => {
    expect(indexFallsBack([{ field: 'description', reason: 'de content is missing; showing it fallback.' }])).toBe(true)
    expect(indexFallsBack([{ reason: 'Missing title' }])).toBe(false)
    expect(indexFallsBack(null)).toBe(false)
  })
  it('uses the resolver for page text and retains missing index as absent/unknown', async () => {
    db.product.findMany.mockResolvedValue([{ id: 'p', name: 'Italian source', description: 'Italian description', translations: [{ language: 'de', name: 'Deutscher Titel', source: 'ai' }] }])
    db.readinessIndex.findMany.mockResolvedValue([])
    const result = (await catalogLanguageValues(['p'], 'de')).get('p')!
    expect(result.title).toMatchObject({ value: 'Deutscher Titel', language: 'de', provenance: { member: 'ai' } })
    expect(result.description).toMatchObject({ value: 'Italian description', language: 'it' })
    expect(result.readiness).toEqual({ state: 'absent', pct: null, computedAt: null })
    expect(result.fallsBackToSource).toBeNull()
  })
  it('applies fallback and readiness predicates in SQL before pagination', async () => {
    db.product.findMany.mockResolvedValue([{ id: 'p' }]); db.$queryRaw.mockResolvedValue([{ id: 'p' }])
    expect(await restrictCatalogLanguage({ language: 'de', languageStates: ['warn'], languageFallback: true }, { familyId: 'xavia' })).toEqual(['p'])
    const sql = db.$queryRaw.mock.calls[0][0]
    expect(sql.sql).toContain('jsonb_array_elements'); expect(sql.sql).toContain('r.channel IS NULL')
    expect(sql.values).toEqual(expect.arrayContaining(['de', 'warn', true]))
    expect(db.product.findMany).toHaveBeenCalledWith({ where: { familyId: 'xavia' }, select: { id: true } })
  })
  it('an empty state selection matches no products', async () => {
    expect(await restrictCatalogLanguage({ language: 'de', languageStates: [] }, {})).toEqual([])
    expect(db.$queryRaw).not.toHaveBeenCalled()
  })
  it('sorts the complete indexed scope before limit/offset with a stable tie break', async () => {
    db.product.findMany.mockResolvedValue([{ id: 'p' }]); db.$queryRaw.mockResolvedValue([{ id: 'p' }])
    await orderCatalogLanguage({ language: 'fr', languageSort: { field: 'readiness', direction: 'desc' } }, {}, 100, 100)
    const sql = db.$queryRaw.mock.calls[0][0]
    expect(sql.sql).toContain('ORDER BY r.state DESC NULLS LAST, p.id ASC LIMIT')
    expect(sql.values.slice(-2)).toEqual([100, 100])
  })
})
