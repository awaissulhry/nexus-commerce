import type { Prisma } from '@prisma/client'
import prisma from '../../db.js'
import { beforeDatabaseCommit, inDatabaseTransaction } from '../../lib/database-context.js'
import { getStudioSheet } from './studio-sheet.service.js'
import { withCachedSchemas } from './cached-schema-context.js'
import { marketLanguages } from './market-languages.js'
import { coordinatesFor } from './sheet-columns.service.js'
import { readinessLanguages, readinessCoordinateKey, readinessFromSheet, type ReadinessCoordinate } from './readiness-model.js'

/** One family refresh per outer write, after cascades/formulas and before commit. */
export async function produceReadiness(productId: string) {
  const product = await prisma.product.findUniqueOrThrow({ where: { id: productId }, select: { id: true, parentId: true } })
  const rootId = product.parentId ?? product.id
  await beforeDatabaseCommit(`readiness:${rootId}`, () => reconcileFamilyReadiness(rootId))
}

/** The only materializer. Schema misses are honest absent rows; persistence failures roll back. */
export async function reconcileFamilyReadiness(productId: string): Promise<number> {
  return inDatabaseTransaction(prisma, () => withCachedSchemas(async () => {
    const product = await prisma.product.findUniqueOrThrow({ where: { id: productId }, select: { id: true, parentId: true } })
    const rootId = product.parentId ?? product.id
    const [products, markets, accounts] = await Promise.all([
      prisma.product.findMany({ where: { OR: [{ id: rootId }, { parentId: rootId }], deletedAt: null }, select: { id: true } }),
      prisma.marketplace.findMany({ where: { isActive: true }, orderBy: [{ channel: 'asc' }, { code: 'asc' }] }),
      prisma.channelConnection.findMany({ where: { isActive: true }, select: { id: true, channelType: true, accountLabel: true, displayName: true } }),
    ])
    const languages = readinessLanguages(markets)
    const destinations: Array<{ coordinate: ReadinessCoordinate; language: string; label: string }> = languages.map(language => ({
      coordinate: { channel: null, market: null, accountId: null, aliasId: null }, language, label: 'Shared product',
    }))
    for (const market of markets) {
      const coordinate = coordinatesFor(market.code, [market])[0]
      if (!coordinate) continue
      const owners = accounts.filter(a => a.channelType === market.channel)
      for (const accountId of owners.length ? owners.map(a => a.id) : [null]) for (const language of marketLanguages(market.channel, market.code, [market])) {
        destinations.push({ coordinate: { channel: market.channel, market: market.code, accountId, aliasId: null }, language, label: `${coordinate.label}${owners.length > 1 ? ` · ${owners.find(a => a.id === accountId)?.accountLabel ?? owners.find(a => a.id === accountId)?.displayName ?? 'Connected account'}` : ''}` })
      }
    }
    const computedAt = new Date()
    const rows: Prisma.ReadinessIndexCreateManyInput[] = []
    for (const { coordinate, language, label } of destinations) {
      let sheet: Awaited<ReturnType<typeof getStudioSheet>> | undefined
      let unavailable: string | undefined
      try {
        if (coordinate.channel && !coordinate.accountId) throw new Error('No active account for this destination.')
        sheet = await getStudioSheet({ productId: rootId, scope: coordinate.channel ? 'channel' : 'master', channel: coordinate.channel ?? undefined,
          market: coordinate.market ?? markets.find(m => m.code !== 'GLOBAL')?.code ?? 'IT', locale: language,
          accountId: coordinate.accountId ?? undefined, includeMapping: !!coordinate.channel })
      } catch (error) {
        // Business/schema availability is a readable state. Never swallow database failures.
        if (error instanceof TypeError || error instanceof ReferenceError || (error as { code?: string }).code?.startsWith('P')) throw error
        unavailable = error instanceof Error ? error.message : 'Requirements could not be checked.'
      }
      if (!sheet) {
        for (const product of products) rows.push({ productId: product.id, ...coordinate, coordinateKey: readinessCoordinateKey(coordinate), language, label,
          pct: null, state: 'absent', requiredFilled: 0, requiredTotal: 0, missing: [], note: unavailable, mappingRules: null, computedAt })
        continue
      }
      const market = markets.find(m => m.channel === coordinate.channel && m.code === coordinate.market)
      const mapping = market?.schemaMapping as { fields?: Record<string, unknown>; byProductType?: Record<string, Record<string, unknown>> } | null
      for (const row of sheet.rows) {
        const c = { ...coordinate, aliasId: row.aliasId }
        const summary = readinessFromSheet({ ...sheet, rows: [row], aliases: sheet.aliases.filter(a => a.id === row.aliasId) }, coordinate.channel ? new Set([
          ...Object.keys(mapping?.fields ?? {}), ...Object.keys(mapping?.byProductType?.[row.productType ?? ''] ?? {}),
        ]).size : null)
        const missing = row.readiness.issues.map(issue => ({ productId: row.id, field: issue.key,
          label: issue.label, reason: issue.message }))
        rows.push({ productId: row.id, ...c, coordinateKey: readinessCoordinateKey(c), language, label: row.aliasId ? `${label} · ${sheet.aliases.find(a => a.id === row.aliasId)?.label ?? 'Listing customization'}` : label,
          pct: summary.pct, state: summary.state, requiredFilled: summary.required.filled, requiredTotal: summary.required.total,
          missing, note: summary.note, mappingRules: summary.mappingRules, computedAt })
      }
    }
    // Only the derived index is replaced; content, versions and legacy bags are untouched.
    await prisma.readinessIndex.deleteMany({ where: { productId: { in: products.map(p => p.id) } } })
    if (rows.length) await prisma.readinessIndex.createMany({ data: rows })
    return rows.length
  }))
}
