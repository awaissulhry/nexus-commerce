import { Prisma } from '@prisma/client'
import type { CatalogLanguageProjection } from '@nexus/shared/products-grid'
import prisma from '../../db.js'
import { normalizeLanguage } from './content-language.js'
import { resolveContent } from './content-resolver.js'
import type { ProductListQuery } from '../products/list-products.service.js'

// LX.5 already materializes this resolver verdict on every applicable text field,
// including optional fields. Match its recorded fallback, never infer from empty text.
const fallbackSql = Prisma.sql`EXISTS (SELECT 1 FROM jsonb_array_elements(r.missing) issue WHERE issue->>'reason' LIKE '%; showing % fallback.')`
export function indexFallsBack(missing: unknown): boolean {
  return Array.isArray(missing) && missing.some(issue => typeof issue?.reason === 'string' && /; showing .+ fallback\.$/.test(issue.reason))
}
export async function restrictCatalogLanguage(q: ProductListQuery, where: Prisma.ProductWhereInput): Promise<string[] | null> {
  if (!q.language || q.languageStates === undefined && q.languageFallback === undefined) return null
  if (q.languageStates?.length === 0) return []
  const candidates = await prisma.product.findMany({ where, select: { id: true } })
  if (!candidates.length) return []
  const states = q.languageStates?.length ? Prisma.sql`AND COALESCE(r.state, 'absent') IN (${Prisma.join(q.languageStates)})` : Prisma.empty
  const fallback = q.languageFallback === undefined ? Prisma.empty : Prisma.sql`AND r.id IS NOT NULL AND ${fallbackSql} = ${q.languageFallback}`
  const rows = await prisma.$queryRaw<Array<{ id: string }>>(Prisma.sql`
    SELECT p.id FROM "Product" p LEFT JOIN "ReadinessIndex" r ON r."productId"=p.id AND r."workspaceId"=p."workspaceId"
      AND r.channel IS NULL AND r.market IS NULL AND r."accountId" IS NULL AND r."aliasId" IS NULL AND r.language=${normalizeLanguage(q.language)}
    WHERE p.id IN (${Prisma.join(candidates.map(p => p.id))}) ${states} ${fallback}`)
  return rows.map(row => row.id)
}

/** Batch only the requested page's content; no sheets and no provider schema reads. */
export async function catalogLanguageValues(ids: string[], language: string): Promise<Map<string, CatalogLanguageProjection>> {
  const requested = normalizeLanguage(language)
  const [products, index] = await Promise.all([
    prisma.product.findMany({ where: { id: { in: ids } }, include: { translations: true, parent: { include: { translations: true } } } }),
    prisma.readinessIndex.findMany({ where: { productId: { in: ids }, language: requested, channel: null, market: null, accountId: null, aliasId: null } }),
  ])
  const readiness = new Map(index.map(row => [row.productId, row]))
  return new Map(products.map(product => {
    const resolve = (field: string) => resolveContent({ product: product as any, parent: product.parent as any, field, address: { requested } })
    const row = readiness.get(product.id)
    return [product.id, { title: resolve('title'), description: resolve('description'),
      readiness: { state: (row?.state ?? 'absent') as CatalogLanguageProjection['readiness']['state'], pct: row?.pct ?? null, computedAt: row?.computedAt.toISOString() ?? null },
      fallsBackToSource: row ? indexFallsBack(row.missing) : null }]
  }))
}

export async function orderCatalogLanguage(q: ProductListQuery, where: Prisma.ProductWhereInput, offset: number, limit: number): Promise<string[]> {
  const candidates = await prisma.product.findMany({ where, select: { id: true }, orderBy: { id: 'asc' } })
  if (!candidates.length) return []
  const sort = q.languageSort!, dir = sort.direction === 'desc' ? Prisma.sql`DESC` : Prisma.sql`ASC`
  if (sort.field === 'readiness' || sort.field === 'fallback') {
    const expression = sort.field === 'fallback' ? Prisma.sql`CASE WHEN r.id IS NULL THEN NULL ELSE ${fallbackSql} END` : Prisma.sql`r.state`
    const rows = await prisma.$queryRaw<Array<{ id: string }>>(Prisma.sql`
      SELECT p.id FROM "Product" p LEFT JOIN "ReadinessIndex" r ON r."productId"=p.id AND r."workspaceId"=p."workspaceId"
        AND r.channel IS NULL AND r.market IS NULL AND r."accountId" IS NULL AND r."aliasId" IS NULL AND r.language=${q.language!}
      WHERE p.id IN (${Prisma.join(candidates.map(p => p.id))}) ORDER BY ${expression} ${dir} NULLS LAST, p.id ASC LIMIT ${limit} OFFSET ${offset}`)
    return rows.map(row => row.id)
  }
  // Text ordering must use the one resolver. Bounded batches keep thousands of
  // full product rows out of memory; only ids and sort text survive each batch.
  const values: Array<{ id: string; text: string }> = []
  for (let start = 0; start < candidates.length; start += 100) {
    const rows = await catalogLanguageValues(candidates.slice(start, start + 100).map(p => p.id), q.language!)
    for (const [id, row] of rows) values.push({ id, text: String(row[sort.field].value ?? '') })
  }
  const direction = sort.direction === 'desc' ? -1 : 1
  return values.sort((a, b) => direction * a.text.localeCompare(b.text, q.language) || a.id.localeCompare(b.id)).slice(offset, offset + limit).map(row => row.id)
}
