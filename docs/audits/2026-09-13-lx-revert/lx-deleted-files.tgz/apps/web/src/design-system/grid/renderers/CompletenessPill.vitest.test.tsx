// @vitest-environment node
import React from 'react'
import { renderToStaticMarkup } from 'react-dom/server'
import { expect, it } from 'vitest'
import { CompletenessPill } from './CompletenessPill'
it('renders an explicit unknown score, without a fabricated percentage or bar', () => {
  const html = renderToStaticMarkup(<CompletenessPill pct={null} state="errors" tip="OUTERWEAR contract not loaded" />)
  expect(html).toContain('—')
  expect(html).toContain('aria-label="OUTERWEAR contract not loaded"')
  expect(html).not.toContain('%')
  expect(html).not.toContain('nds-readypill-track')
})
it('retains a measured zero and the independent error tone', () => {
  const html = renderToStaticMarkup(<CompletenessPill pct={0} state="errors" />)
  expect(html).toContain('0%')
  expect(html).toContain('nds-readypill-danger')
})
